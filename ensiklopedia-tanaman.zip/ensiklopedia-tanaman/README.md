# Ensiklopedia Tanaman Indonesia

"Menjelajahi Keanekaragaman Flora Nusantara"

Website ensiklopedia tanaman Indonesia berbasis HTML, CSS, dan JavaScript murni. Tidak menggunakan framework apa pun (tanpa React, Next.js, Vue, atau Angular).

## Struktur Proyek

```
ensiklopedia-tanaman/
├── index.html        Beranda
├── database.html     Katalog tanaman (pencarian, filter, pengurutan, pagination)
├── detail.html       Halaman detail tanaman (diisi berdasarkan ?slug=)
├── klasifikasi.html  Penelusuran berdasarkan taksonomi
├── style.css         Seluruh gaya visual dan responsivitas
├── script.js         Logika aplikasi (render, filter, navigasi)
├── data/
│   └── plants.js     Database 50 tanaman
├── assets/
│   ├── images/       Foto tanaman dan aset gambar
│   └── icons/        Ikon
└── README.md
```

## Cara Menjalankan di JupyterLab

1. Buka JupyterLab dan masuk ke folder tempat proyek ini disimpan (misalnya hasil ekstrak ZIP, yaitu folder `ensiklopedia-tanaman`).
2. Buka **Terminal** (menu File → New → Terminal).
3. Pastikan posisi terminal berada di dalam folder proyek. Jalankan `pwd` untuk memeriksanya, dan `ls` untuk memastikan ada `index.html`.
4. Jalankan perintah berikut:

   ```bash
   python -m http.server 8000
   ```

5. Buka browser dan kunjungi **http://localhost:8000**
6. Untuk menghentikan server, kembali ke terminal dan tekan `Ctrl + C`.

> Catatan: jika `python` tidak dikenali, coba `python3 -m http.server 8000`.
> Jika port 8000 sudah dipakai, gunakan port lain, misalnya `python -m http.server 8080`, lalu buka `http://localhost:8080`.

Website harus dijalankan melalui server lokal (bukan dengan membuka file `index.html` langsung dari file manager), karena halaman memuat berkas JavaScript dan data secara lokal.

## Fitur

- Pencarian nama lokal dan nama ilmiah (tidak sensitif huruf besar-kecil dan aksen).
- Filter berdasarkan famili dan kategori.
- Pengurutan nama lokal A–Z, Z–A, dan nama ilmiah A–Z.
- Pagination 12 tanaman per halaman.
- Halaman detail lengkap dengan breadcrumb, navigasi sebelumnya/berikutnya, dan galeri.
- Halaman klasifikasi taksonomi.
- Tampilan responsif untuk desktop, tablet, dan smartphone (menu hamburger di layar kecil).
- Fallback jika foto gagal dimuat atau belum tersedia.
- Halaman 404 untuk tanaman yang tidak ditemukan, misalnya `detail.html?slug=tidak-ada`.

## Cara Menambah Tanaman Baru

Tambahkan objek baru ke array `PLANTS` di `data/plants.js`, mengikuti struktur berikut:

```js
buatTanaman({
  id: "051",
  slug: "nama-slug",          // huruf kecil, tanpa spasi, unik
  nama_lokal: "Nama Lokal",
  nama_ilmiah: "Genus species Author",
  famili: "Famili",
  genus: "Genus",
  spesies: "Genus species Author",
  kategori: "Tanaman buah",   // salah satu dari 6 kategori yang sudah ada
  // isi field lainnya sesuai data yang sudah terverifikasi
  sumber_referensi: [SUMBER.POWO, SUMBER.PROSEA]
})
```

Field yang tidak diisi otomatis bernilai "Perlu verifikasi" atau "Belum tersedia". Semua kategori dan famili di filter dihitung otomatis dari data.

## Status Data (Penting)

Database awal berisi 50 spesies sesuai daftar proyek. Status isi data adalah sebagai berikut:

- **Nama ilmiah, famili, dan genus** ditulis berdasarkan nomenklatur botani yang umum digunakan. Tetap perlu dicocokkan dengan Plants of the World Online (Kew) sebelum publikasi.
- **Deskripsi, morfologi, habitat, syarat tumbuh, dan asal/persebaran** masih bersifat ringkas dan umum. Banyak field bertanda **"Perlu verifikasi"** karena belum dikonfirmasi terhadap sumber primer. Field tersebut perlu dilengkapi dari sumber yang tercantum.
- **Status konservasi** sebagian besar belum tersedia. Silakan isi dari IUCN Red List atau peraturan nasional yang berlaku.
- **Foto** belum terisi untuk semua tanaman. Halaman akan menampilkan placeholder sampai file foto ditambahkan ke `assets/images/` dan path-nya diisi di field `foto_utama`.
- **Spesies dengan nama tingkat genus**: `Shorea sp.` (Meranti) dan `Nepenthes sp.` (Kantong semar) mewakili kelompok, bukan satu spesies tunggal. Perlu dipilih satu spesies yang jelas agar sesuai ketentuan proyek.
- **Sumber referensi**: setiap tanaman mencantumkan tautan ke lembaga sumber (POWO, WFO, GBIF, Catalogue of Life, PROSEA). Tautan tersebut adalah halaman utama, bukan halaman spesifik yang sudah diperiksa satu per satu.

## Sumber Referensi

- Plants of the World Online (Royal Botanic Gardens, Kew): https://powo.science.kew.org/
- World Flora Online: https://www.worldfloraonline.org/
- GBIF: https://www.gbif.org/
- Catalogue of Life: https://www.catalogueoflife.org/
- PROSEA (Plant Resources of South-East Asia): https://www.prosea.org/

## Lisensi dan Penggunaan

Informasi dalam website ini bersifat edukatif. Untuk keperluan ilmiah atau publikasi, periksa kembali setiap data pada sumber primernya.
