/* =========================================================
   Ensiklopedia Tanaman Indonesia - script utama
   Bergantung pada data/plants.js (PLANTS, SUMBER, KATEGORI, FAMILI)
   ========================================================= */

(function () {
  "use strict";

  // ---------- Utilitas ----------
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  function escapeHtml(teks) {
    return String(teks ?? "")
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function normalisasi(teks) {
    return String(teks ?? "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
  }

  function urutkanAlfabetis(daftar) {
    return [...daftar].sort((a, b) => a.nama_lokal.localeCompare(b.nama_lokal, "id"));
  }

  function isiTeks(nilai) {
    return nilai && nilai.trim() !== "" ? nilai : "Belum tersedia";
  }

  // Menandai teks "Perlu verifikasi" dengan gaya khusus
  function teksData(nilai) {
    const teks = isiTeks(nilai);
    if (teks === "Perlu verifikasi" || teks === "Belum tersedia") {
      return `<span class="perlu">${escapeHtml(teks)}</span>`;
    }
    return escapeHtml(teks);
  }

  // Foto dengan fallback jika gagal dimuat
  function blokFoto(tanaman, kelas = "") {
    const src = tanaman.foto_utama;
    const ikonFallback = `
      <div class="foto-fallback">
        <span class="ikon">🌿</span>
        <span>Foto belum tersedia</span>
      </div>`;
    if (!src) return `<div class="${kelas}">${ikonFallback}</div>`;
    return `
      <div class="${kelas}">
        <img src="${escapeHtml(src)}" alt="${escapeHtml(tanaman.nama_lokal)}" loading="lazy"
             onerror="this.parentElement.innerHTML='<div class=&quot;foto-fallback&quot;><span class=&quot;ikon&quot;>🌿</span><span>Foto belum tersedia</span></div>'">
      </div>`;
  }

  // ---------- Pengambilan data ----------
  function cariBerdasarkanSlug(slug) {
    return PLANTS.find(p => p.slug === slug) || null;
  }

  // ---------- Komponen kartu ----------
  function kartuTanaman(t) {
    return `
      <article class="kartu">
        ${blokFoto(t, "kartu-foto")}
        <div class="kartu-body">
          <h3>${escapeHtml(t.nama_lokal)}</h3>
          <div class="nama-ilmiah">${escapeHtml(t.nama_ilmiah)}</div>
          <div class="badge-row">
            <span class="badge">${escapeHtml(t.famili || "Famili belum tersedia")}</span>
            <span class="badge kategori">${escapeHtml(t.kategori || "Kategori belum tersedia")}</span>
          </div>
          <div class="kartu-aksi">
            <a class="btn" href="detail.html?slug=${encodeURIComponent(t.slug)}">Lihat detail</a>
          </div>
        </div>
      </article>`;
  }

  // ---------- Navigasi responsif ----------
  function inisialisasiNavigasi() {
    const tombol = $(".nav-toggle");
    const menu = $(".nav-links");
    if (tombol && menu) {
      tombol.addEventListener("click", () => {
        const terbuka = menu.classList.toggle("buka");
        tombol.setAttribute("aria-expanded", String(terbuka));
      });
    }
    // Tandai tautan aktif berdasarkan nama file
    const halamanSaatIni = window.location.pathname.split("/").pop() || "index.html";
    $$(".nav-links a").forEach(a => {
      const tujuan = a.getAttribute("href").split("?")[0];
      if (tujuan === halamanSaatIni) a.classList.add("aktif");
    });
  }

  // ---------- Halaman: Beranda ----------
  function halamanBeranda() {
    const statFamili = new Set(PLANTS.map(p => p.famili).filter(Boolean)).size;
    const statKategori = KATEGORI.length;
    const setAngka = (id, nilai) => { const el = $(id); if (el) el.textContent = nilai; };
    setAngka("#stat-spesies", PLANTS.length);
    setAngka("#stat-famili", statFamili);
    setAngka("#stat-kategori", statKategori);

    // Tanaman unggulan (beberapa pilihan tetap)
    const unggulan = ["mangga", "kopi", "padi", "jati", "rafflesia-arnoldii", "kelapa"]
      .map(cariBerdasarkanSlug).filter(Boolean);
    const wadahUnggulan = $("#unggulan");
    if (wadahUnggulan) wadahUnggulan.innerHTML = unggulan.map(kartuTanaman).join("");

    // Katalog terbaru (ambil entri terakhir)
    const terbaru = PLANTS.slice(-6).reverse();
    const wadahTerbaru = $("#terbaru");
    if (wadahTerbaru) wadahTerbaru.innerHTML = terbaru.map(kartuTanaman).join("");

    // Kategori
    const wadahKategori = $("#kategori");
    if (wadahKategori) {
      const ikon = {
        "Tanaman buah": "🍈", "Tanaman pangan": "🌾", "Tanaman hortikultura": "🥬",
        "Tanaman perkebunan": "☕", "Tanaman obat dan aromatik": "🌿", "Tanaman kehutanan dan hias": "🌳"
      };
      wadahKategori.innerHTML = KATEGORI.map(k => {
        const jumlah = PLANTS.filter(p => p.kategori === k).length;
        return `
          <a class="kategori-card" href="database.html?kategori=${encodeURIComponent(k)}">
            <div class="ikon">${ikon[k] || "🌱"}</div>
            <h3>${escapeHtml(k)}</h3>
            <span>${jumlah} spesies</span>
          </a>`;
      }).join("");
    }

    // Pencarian di beranda diarahkan ke halaman database
    const formCari = $("#form-cari-hero");
    if (formCari) {
      formCari.addEventListener("submit", e => {
        e.preventDefault();
        const q = $("#q-hero").value.trim();
        window.location.href = `database.html?q=${encodeURIComponent(q)}`;
      });
    }
  }

  // ---------- Halaman: Database ----------
  function halamanDatabase() {
    const elQ = $("#q");
    const elFamili = $("#filter-famili");
    const elKategori = $("#filter-kategori");
    const elUrut = $("#urut");
    const elHasil = $("#hasil");
    const elInfo = $("#hasil-info");
    const elPagination = $("#pagination");
    const elReset = $("#reset");

    const PER_HALAMAN = 12;
    let halamanAktif = 1;

    // Isi opsi filter
    elFamili.innerHTML = `<option value="">Semua famili</option>` +
      FAMILI.map(f => `<option value="${escapeHtml(f)}">${escapeHtml(f)}</option>`).join("");
    elKategori.innerHTML = `<option value="">Semua kategori</option>` +
      KATEGORI.map(k => `<option value="${escapeHtml(k)}">${escapeHtml(k)}</option>`).join("");

    // Baca parameter URL awal
    const params = new URLSearchParams(window.location.search);
    if (params.get("q")) elQ.value = params.get("q");
    if (params.get("kategori") && KATEGORI.includes(params.get("kategori"))) elKategori.value = params.get("kategori");
    if (params.get("famili") && FAMILI.includes(params.get("famili"))) elFamili.value = params.get("famili");

    function terapkanFilter() {
      const kata = normalisasi(elQ.value);
      const famili = elFamili.value;
      const kategori = elKategori.value;

      let hasil = PLANTS.filter(p => {
        if (famili && p.famili !== famili) return false;
        if (kategori && p.kategori !== kategori) return false;
        if (kata) {
          const cocok =
            normalisasi(p.nama_lokal).includes(kata) ||
            normalisasi(p.nama_ilmiah).includes(kata) ||
            normalisasi(p.spesies).includes(kata);
          if (!cocok) return false;
        }
        return true;
      });

      if (elUrut.value === "za") hasil = urutkanAlfabetis(hasil).reverse();
      else if (elUrut.value === "ilmiah") hasil = [...hasil].sort((a, b) => a.nama_ilmiah.localeCompare(b.nama_ilmiah, "en"));
      else hasil = urutkanAlfabetis(hasil);

      return hasil;
    }

    function render() {
      const hasil = terapkanFilter();
      const totalHalaman = Math.max(1, Math.ceil(hasil.length / PER_HALAMAN));
      if (halamanAktif > totalHalaman) halamanAktif = totalHalaman;

      const mulai = (halamanAktif - 1) * PER_HALAMAN;
      const potongan = hasil.slice(mulai, mulai + PER_HALAMAN);

      elInfo.innerHTML = `<span>Menampilkan <strong>${potongan.length}</strong> dari <strong>${hasil.length}</strong> tanaman</span>
                          <span>Halaman ${halamanAktif} dari ${totalHalaman}</span>`;

      if (hasil.length === 0) {
        elHasil.innerHTML = `
          <div class="kosong" style="grid-column: 1/-1">
            <div class="ikon">🔍</div>
            <h3>Tanaman tidak ditemukan</h3>
            <p>Coba kata kunci lain atau atur ulang filter pencarian.</p>
          </div>`;
        elPagination.innerHTML = "";
        return;
      }

      elHasil.innerHTML = potongan.map(kartuTanaman).join("");
      renderPagination(totalHalaman);
    }

    function renderPagination(total) {
      if (total <= 1) { elPagination.innerHTML = ""; return; }
      let html = `<button class="btn btn-outline" data-hal="${halamanAktif - 1}" ${halamanAktif === 1 ? "disabled" : ""}>← Sebelumnya</button>`;
      for (let i = 1; i <= total; i++) {
        html += `<button class="btn ${i === halamanAktif ? "" : "btn-outline"}" data-hal="${i}" aria-label="Halaman ${i}">${i}</button>`;
      }
      html += `<button class="btn btn-outline" data-hal="${halamanAktif + 1}" ${halamanAktif === total ? "disabled" : ""}>Berikutnya →</button>`;
      elPagination.innerHTML = html;
    }

    // Debounce untuk input pencarian
    let timer;
    elQ.addEventListener("input", () => {
      clearTimeout(timer);
      timer = setTimeout(() => { halamanAktif = 1; render(); }, 180);
    });
    [elFamili, elKategori, elUrut].forEach(el => el.addEventListener("change", () => { halamanAktif = 1; render(); }));

    elPagination.addEventListener("click", e => {
      const btn = e.target.closest("button[data-hal]");
      if (!btn || btn.disabled) return;
      halamanAktif = Number(btn.dataset.hal);
      render();
      window.scrollTo({ top: elHasil.offsetTop - 100, behavior: "smooth" });
    });

    elReset.addEventListener("click", () => {
      elQ.value = ""; elFamili.value = ""; elKategori.value = ""; elUrut.value = "az";
      halamanAktif = 1; render();
    });

    render();
  }

  // ---------- Halaman: Detail ----------
  function halamanDetail() {
    const wadah = $("#detail-root");
    const params = new URLSearchParams(window.location.search);
    const slug = params.get("slug");
    const t = slug ? cariBerdasarkanSlug(slug) : null;

    if (!t) {
      document.title = "Tanaman tidak ditemukan · Ensiklopedia Tanaman Indonesia";
      wadah.innerHTML = `
        <div class="halaman-404">
          <div class="kode">404</div>
          <h2>Tanaman tidak ditemukan</h2>
          <p style="margin:0.6rem 0 1.6rem; color:var(--teks-muda)">Tanaman dengan pengenal "${escapeHtml(slug || "-")}" tidak tersedia dalam database.</p>
          <a class="btn" href="database.html">Kembali ke katalog</a>
        </div>`;
      return;
    }

    document.title = `${t.nama_lokal} · Ensiklopedia Tanaman Indonesia`;
    const idx = PLANTS.indexOf(t);
    const sebelumnya = PLANTS[idx - 1];
    const berikutnya = PLANTS[idx + 1];

    const fakta = [
      ["Famili", t.famili], ["Genus", t.genus], ["Kategori", t.kategori], ["Status konservasi", t.status_konservasi]
    ].map(([k, v]) => `<div class="fakta"><small>${k}</small><strong>${teksData(v)}</strong></div>`).join("");

    const taksonomi = [
      ["Kerajaan", t.kerajaan], ["Divisi", t.divisi], ["Kelas", t.kelas], ["Ordo", t.ordo],
      ["Famili", t.famili], ["Genus", t.genus], ["Spesies", t.spesies]
    ].map(([k, v]) => {
      const isi = (k === "Spesies" || k === "Genus") && v
        ? `<em>${escapeHtml(v)}</em>` : teksData(v);
      return `<tr><th>${k}</th><td>${isi}</td></tr>`;
    }).join("");

    const galeri = (t.galeri && t.galeri.length)
      ? `<div class="galeri">${t.galeri.map(g => blokFoto({ foto_utama: g, nama_lokal: t.nama_lokal }, "kartu-foto")).join("")}</div>`
      : `<p class="perlu">Galeri belum tersedia.</p>`;

    const sumber = (t.sumber_referensi && t.sumber_referensi.length)
      ? `<ul class="sumber-list">${t.sumber_referensi.map(s =>
          `<li>${escapeHtml(s.judul)}<br><a href="${escapeHtml(s.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(s.url)}</a></li>`
        ).join("")}</ul>`
      : `<p class="perlu">Perlu verifikasi</p>`;

    const sinonim = (t.sinonim && t.sinonim.length)
      ? `<div class="sinonim">Sinonim: ${t.sinonim.map(escapeHtml).join(", ")}</div>`
      : `<div class="sinonim">Sinonim: ${teksData("")}</div>`;

    wadah.innerHTML = `
      <nav class="breadcrumb" aria-label="Breadcrumb">
        <a href="index.html">Beranda</a><span class="sep">/</span>
        <a href="database.html">Database</a><span class="sep">/</span>
        <span>${escapeHtml(t.nama_lokal)}</span>
      </nav>

      <section class="detail-layout">
        ${blokFoto(t, "detail-foto")}
        <div class="detail-info">
          <span class="badge kategori">${escapeHtml(t.kategori || "Kategori belum tersedia")}</span>
          <h1>${escapeHtml(t.nama_lokal)}</h1>
          <div class="ilmiah">${escapeHtml(t.nama_ilmiah)}</div>
          ${sinonim}
          <div class="fakta-grid">${fakta}</div>
          <a class="btn btn-outline" href="database.html">← Kembali ke katalog</a>
        </div>
      </section>

      <section class="detail-section"><h2>Deskripsi umum</h2><p>${teksData(t.deskripsi)}</p></section>
      <section class="detail-section"><h2>Asal dan persebaran</h2>
        <p><strong>Asal:</strong> ${teksData(t.asal)}</p>
        <p><strong>Persebaran:</strong> ${teksData(t.persebaran)}</p>
      </section>
      <section class="detail-section"><h2>Klasifikasi taksonomi</h2>
        <table class="taksonomi"><tbody>${taksonomi}</tbody></table>
      </section>
      <section class="detail-section"><h2>Karakteristik morfologi</h2><p>${teksData(t.morfologi)}</p></section>
      <section class="detail-section"><h2>Habitat dan ekologi</h2><p>${teksData(t.habitat)}</p></section>
      <section class="detail-section"><h2>Syarat tumbuh</h2><p>${teksData(t.syarat_tumbuh)}</p></section>
      <section class="detail-section"><h2>Manfaat dan pemanfaatan</h2><p>${teksData(t.manfaat)}</p></section>
      <section class="detail-section"><h2>Status konservasi</h2><p>${teksData(t.status_konservasi)}</p></section>
      <section class="detail-section"><h2>Galeri foto</h2>${galeri}</section>
      <section class="detail-section"><h2>Referensi dan sumber informasi</h2>${sumber}</section>

      <div class="prev-next">
        ${sebelumnya ? `<a class="btn btn-outline" href="detail.html?slug=${encodeURIComponent(sebelumnya.slug)}">← ${escapeHtml(sebelumnya.nama_lokal)}</a>` : "<span></span>"}
        ${berikutnya ? `<a class="btn btn-outline" href="detail.html?slug=${encodeURIComponent(berikutnya.slug)}">${escapeHtml(berikutnya.nama_lokal)} →</a>` : "<span></span>"}
      </div>`;
  }

  // ---------- Halaman: Klasifikasi ----------
  function halamanKlasifikasi() {
    const wadahMenu = $("#klas-menu");
    const wadahTree = $("#klas-tree");

    // Kelompokkan berdasarkan famili lalu genus, dengan kategori sebagai filter
    const grup = {};
    PLANTS.forEach(p => {
      const f = p.famili || "Famili belum tersedia";
      const g = p.genus || "Genus belum tersedia";
      if (!grup[f]) grup[f] = {};
      if (!grup[f][g]) grup[f][g] = [];
      grup[f][g].push(p);
    });

    const tingkatTersedia = [
      { id: "kerajaan", label: "Kerajaan" },
      { id: "divisi", label: "Divisi" },
      { id: "kelas", label: "Kelas" },
      { id: "ordo", label: "Ordo" },
      { id: "famili", label: "Famili" },
      { id: "genus", label: "Genus" },
      { id: "spesies", label: "Spesies" }
    ];

    wadahMenu.innerHTML = tingkatTersedia.map((t, i) =>
      `<button data-tingkat="${t.id}" class="${i === 4 ? "aktif" : ""}">${t.label}</button>`
    ).join("");

    function renderTreeFamili() {
      const keys = Object.keys(grup).sort((a, b) => a.localeCompare(b, "id"));
      wadahTree.innerHTML = keys.map(f => {
        const genera = Object.keys(grup[f]).sort();
        const totalSpesies = genera.reduce((n, g) => n + grup[f][g].length, 0);
        return `
          <details class="tree-node">
            <summary>${escapeHtml(f)}<span class="jumlah">${totalSpesies} spesies</span></summary>
            <ul>
              ${genera.map(g => `
                <li><em>${escapeHtml(g)}</em>
                  <ul>
                    ${grup[f][g].map(p => `<li><a href="detail.html?slug=${encodeURIComponent(p.slug)}">${escapeHtml(p.nama_lokal)}</a> <span class="jumlah">${escapeHtml(p.nama_ilmiah)}</span></li>`).join("")}
                  </ul>
                </li>`).join("")}
            </ul>
          </details>`;
      }).join("");
    }

    function renderTreeKerajaan() {
      wadahTree.innerHTML = `
        <div class="tree-node">
          <summary>Plantae</summary>
          <p style="margin:0.6rem 0 0.2rem">Seluruh ${PLANTS.length} spesies dalam database termasuk kerajaan Plantae.</p>
          <p class="perlu">Divisi, kelas, dan ordo belum diisi untuk seluruh spesies (perlu verifikasi).</p>
        </div>`;
    }

    function renderBelumTersedia(label) {
      wadahTree.innerHTML = `
        <div class="kosong">
          <div class="ikon">🧭</div>
          <h3>Data ${label.toLowerCase()} belum tersedia</h3>
          <p>Nilai ${label.toLowerCase()} belum terverifikasi untuk tanaman dalam database ini.
             Silakan gunakan tingkat <strong>Famili</strong> atau <strong>Genus</strong> untuk menelusuri.</p>
        </div>`;
    }

    function tampilkan(id) {
      $$("button", wadahMenu).forEach(b => b.classList.toggle("aktif", b.dataset.tingkat === id));
      if (id === "famili") renderTreeFamili();
      else if (id === "genus") renderTreeFamili();
      else if (id === "kerajaan") renderTreeKerajaan();
      else if (id === "spesies") {
        wadahTree.innerHTML = PLANTS.map(p => `
          <div class="tree-node">
            <a href="detail.html?slug=${encodeURIComponent(p.slug)}"><strong>${escapeHtml(p.nama_lokal)}</strong></a>
            <div class="nama-ilmiah">${escapeHtml(p.spesies)}</div>
          </div>`).join("");
      } else {
        const label = tingkatTersedia.find(t => t.id === id).label;
        renderBelumTersedia(label);
      }
    }

    wadahMenu.addEventListener("click", e => {
      const b = e.target.closest("button[data-tingkat]");
      if (b) tampilkan(b.dataset.tingkat);
    });

    tampilkan("famili");
  }

  // ---------- Inisialisasi per halaman ----------
  document.addEventListener("DOMContentLoaded", () => {
    if (typeof PLANTS === "undefined") {
      document.body.insertAdjacentHTML("afterbegin",
        `<div class="error-box" style="margin:2rem">Data tanaman gagal dimuat. Pastikan file data/plants.js tersedia.</div>`);
      return;
    }
    inisialisasiNavigasi();
    const halaman = document.body.dataset.halaman;
    try {
      if (halaman === "beranda") halamanBeranda();
      else if (halaman === "database") halamanDatabase();
      else if (halaman === "detail") halamanDetail();
      else if (halaman === "klasifikasi") halamanKlasifikasi();
    } catch (err) {
      console.error("Kesalahan saat memuat halaman:", err);
    }
  });
})();
